#include <iostream>
#include <cmath>
#include <sstream>
#include <string>
using namespace std;
int solveQuartic(double a, double b, double c, double x[])
{
    
    if (a == 0 && b == 0 && c == 0)
    {
        return -1;
    }

    if (a == 0 && b == 0)
    {
        return 0;
    }
    if (a == 0)
    {
        double y = -c / b;
        if (y < 0)
            return 0;
        x[0] = sqrt(y);
        x[1] = -sqrt(y);
        return 2;
    }
    double delta = b * b - 4 * a * c;
    if (delta < 0)
        return 0;
    double y1 = (-b + sqrt(delta)) / (2 * a);
    double y2 = (-b - sqrt(delta)) / (2 * a);
    int count = 0;
    if (y1 >= 0)
    {
        x[count++] = sqrt(y1);
        x[count++] = -sqrt(y1);
    }
    if (y2 >= 0 && y2 != y1)
    {
        x[count++] = sqrt(y2);
        x[count++] = -sqrt(y2);
    }
    return count;
}

void test_case(double a, double b, double c, const string &expected)
{
    static int test_count = 0;  // Biến static - chỉ khởi tạo 1 lần
    test_count++;
    double x[4];
    int n= solveQuartic(a,b,c,x);
    cout << "Testcase " << test_count << ": a=" << a << ", b=" << b << ", c=" << c << endl;
    ostringstream ss;
    if(n == -1) ss<<"Infinite solutions.";
    else if(n==0) ss <<"No solution.";
    else {
        ss <<"The equation has " << n << " real solution(s): ";
        for(int i=0; i<n; i++)
        {
            ss << x[i] << " ";
        }
    }
    string result = ss.str();
    if(result == expected){
        cout << "PASSED" << endl;
    }
    else {
        cout << "FAILED" << endl;
    }
    cout << "EXPECTED: " << expected << endl;
    cout << "OUTPUT: " << result << endl;
    cout << "----------------------------------" << endl;

}
int main()
{
    double a, b, c;
    cin >> a >> b >> c;
    double x[4];
    int n = solveQuartic(a, b, c, x);
    if (n == -1)
    {
        cout << " Infinite solutions." << endl;
    }
    else if (n == 0)
    {
        cout << "No solution." << endl;
    }
    else
    {
        cout << " The equation has " << n << " real solution(s): ";
        for (int i = 0; i < n; i++)
        {
            cout << x[i] << " ";
        }

        cout << endl;
    }

    test_case(0, 0, 0, "Infinite solutions.");
    test_case(0, 0, 2, "No solution.");
    test_case(0, 1, 4, "No solution.");
    test_case(0, 1, -4, "The equation has 2 real solution(s): 2 -2 ");
    test_case(0, -1, 4, "The equation has 2 real solution(s): 2 -2 ");
    test_case(0, -1, -4, "No solution.");
    test_case(1, 1, 4, "No solution.");
    test_case(1, 0, -1, "The equation has 2 real solution(s): 1 -1 ");
    test_case(1, -5, 4, "The equation has 4 real solution(s): 2 -2 1 -1 ");
    test_case(1, 0, 1, "No solution.");
    test_case(1, 2, 1, "No solution.");  
    test_case(1, -2, 1, "The equation has 2 real solution(s): 1 -1 "); 
    test_case(-1, 0, 1, "The equation has 2 real solution(s): 1 -1 "); 
    test_case(-1, 5, -4, "The equation has 4 real solution(s): 1 -1 2 -2 "); 
    
    
    return 0;
}